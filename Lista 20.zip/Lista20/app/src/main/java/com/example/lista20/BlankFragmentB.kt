package com.example.lista20

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.lista20.databinding.FragmentBlankBBinding

class BlankFragmentB : Fragment() {
    private lateinit var binding: FragmentBlankBBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentBlankBBinding.inflate(layoutInflater)
        binding.loginButton.setOnClickListener {
            val action = BlankFragmentBDirections.actionBlankFragmentBToBlankFragmentD()
            Navigation.findNavController(requireView()).navigate(action)
        }
        binding.registerButton.setOnClickListener {
            val action = BlankFragmentBDirections.actionBlankFragmentBToBlankFragmentC()
            Navigation.findNavController(requireView()).navigate(action)
        }
        return binding.root
    }
}
