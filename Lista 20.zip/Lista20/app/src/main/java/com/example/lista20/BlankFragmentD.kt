package com.example.lista20

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.lista20.databinding.FragmentBlankDBinding

class BlankFragmentD : Fragment() {
    private lateinit var binding: FragmentBlankDBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentBlankDBinding.inflate(layoutInflater)

        // Retrieve the username from arguments or shared preferences
        val username = arguments?.getString("username") ?: "User"
        binding.greetingTextView.text = "Witaj $username"

        binding.logoutButton.setOnClickListener {
            // Handle logout logic here (e.g., clear user session)
            val action = BlankFragmentDDirections.actionBlankFragmentDToBlankFragmentB()
            Navigation.findNavController(requireView()).navigate(action)
        }
        return binding.root
    }
}
 