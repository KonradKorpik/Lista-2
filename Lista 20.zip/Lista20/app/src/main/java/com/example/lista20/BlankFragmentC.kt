package com.example.lista20

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.lista20.databinding.FragmentBlankCBinding

class BlankFragmentC : Fragment() {
    private lateinit var binding: FragmentBlankCBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentBlankCBinding.inflate(layoutInflater)
        binding.registerButton.setOnClickListener {
            val action = BlankFragmentCDirections.actionBlankFragmentCToBlankFragmentB()
            Navigation.findNavController(requireView()).navigate(action)
        }
        return binding.root
    }
}